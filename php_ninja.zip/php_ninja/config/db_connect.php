<?php

// Connect to Database
$conn = mysqli_connect('localhost', 'root', '', 'php_ninja');

// check connection
if (!$conn) {
    echo 'Connection error: ' . mysqli_connect_error();
}