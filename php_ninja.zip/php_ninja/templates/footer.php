<footer class="section">
    <div class="center gray-text">
        Copyright 2020 Ninja Pizza
    </div>
</footer>

</body>