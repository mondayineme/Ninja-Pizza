<?php

include('./config/db_connect.php');
// $errors = array("email" => "", "title" => "", "ingredients" => "");

$email_error = $title_error = $ingredients_error = "";

$email = $title = $ingredients = "";

if (isset($_POST['submit'])) {

    //Check Email
    if (empty($_POST['email'])) {
        $email_error = "Email is required <br/>";
    } else {
        $email = $_POST['email'];
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $email_error = "Email must be a valid email address";
        }
    }

    //Check Title
    if (empty($_POST['title'])) {
        $title_error = "Title is required <br/>";
    } else {
        $title = $_POST['title'];
        if (!preg_match("/^[a-zA-Z\s]+$/", $title)) {
            $title_error = "Title must be letters and spaces only";
        }
    }

    //Check Ingredients
    if (empty($_POST['ingredients'])) {
        $ingredients_error = "Ingredients is required <br/>";
    } else {
        $ingredients = $_POST['ingredients'];
        if (!preg_match('/^([a-zA-Z\s]+)(,\s*[a-zA-Z\s]*)*$/', $ingredients)) {
            $ingredients_error = 'Ingredients must be a comma separated list';
        }
    }

    if (!empty($email_error) || !empty($title_error) || !empty($ingredients_error)) {
        // echo "Error in the form. Please try again.";
    } else {

        // Define the values using mysqli escape string to avoid SQL injection to the database
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $title = mysqli_real_escape_string($conn, $_POST['title']);
        $ingredients = mysqli_real_escape_string($conn, $_POST['ingredients']);

        // Create sql strings
        $sql = "INSERT INTO pizzas(title, email, ingredients) VALUES('$title', '$email', '$ingredients')";

        // save to database and check
        if (mysqli_query($conn, $sql)) {
            // Success
            header('Location: index.php');
        } else {
            // error
            echo 'Query error :' . mysqli_error($conn);
        }

        // echo "Form is valid.";

    }
}

?>

<!DOCTYPE html>
<html lang="en">

    <?php include("templates/header.php") ?>

    <section class="container grey-text">
        <h4 class="center">Add a Pizza</h4>
        <form action="add.php" class="white" method="POST" autocomplete="off">
            <label for="">Your Email:</label>
            <input type="text" name="email" value="<?php echo htmlspecialchars($email) ?>">
            <div class="red-text"> <?php echo $email_error; ?> </div>
            <label for="">Pizza Title:</label>
            <input type="text" name="title" value="<?php echo htmlspecialchars($title) ?>">
            <div class="red-text"> <?php echo $title_error; ?> </div>
            <label for="">Ingredient (comma seperated): </label>
            <input type="text" name="ingredients" value="<?php echo htmlspecialchars($ingredients) ?>">
            <div class="red-text"> <?php echo $ingredients_error; ?> </div>

            <div class="center">
                <input type="submit" value="Submit" name="submit" class="btn brand z-depth-0">
            </div>
        </form>
    </section>

    <?php include("templates/footer.php") ?>

</html>